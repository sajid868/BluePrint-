CREATE TABLE students(
id SERIAL PRIMARY KEY,
name TEXT NOT NULL,
roll VARCHAR(30) UNIQUE,
registration VARCHAR(30),
department TEXT,
semester INT
);